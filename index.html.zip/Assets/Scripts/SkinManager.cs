
using UnityEngine;

public class SkinManager : MonoBehaviour {
    public Material[] skins;
    public Renderer playerRenderer;

    public void SetSkin(int id) {
        playerRenderer.material = skins[id];
    }
}
