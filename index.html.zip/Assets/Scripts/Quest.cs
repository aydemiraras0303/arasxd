
using UnityEngine;

[System.Serializable]
public class Quest {
    public string title;
    public int targetCount;
    public int currentCount;
    public int reward;

    public bool IsComplete() {
        return currentCount >= targetCount;
    }
}
