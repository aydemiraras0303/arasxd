
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {
    public static GameManager instance;
    public int coins = 0;
    public Text coinText;

    void Awake() { instance = this; }

    void Update() {
        coinText.text = "Coins: " + coins;
    }

    public void AddCoin() { coins++; }
}
