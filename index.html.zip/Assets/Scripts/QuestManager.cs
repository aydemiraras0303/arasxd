
using UnityEngine;
using UnityEngine.UI;

public class QuestManager : MonoBehaviour {
    public static QuestManager instance;
    public Quest[] quests;
    public Text questText;

    void Awake() { instance = this; }

    void Update() {
        foreach(var q in quests) {
            questText.text = q.title + ": " + q.currentCount + "/" + q.targetCount;
        }
    }

    public void AddProgress(int id) {
        quests[id].currentCount++;
        if(quests[id].IsComplete()) {
            GameManager.instance.coins += quests[id].reward;
        }
    }
}
